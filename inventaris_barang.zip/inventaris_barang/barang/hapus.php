<?php
session_start();
include '../config/koneksi.php';
$id = $_GET['id'];
$conn->query("DELETE FROM barang WHERE id_barang=$id");
header("Location: index.php");
$_SESSION['success'] = "Data berhasil di hapus!";
    header("Location: index.php");
    exit;
?>
