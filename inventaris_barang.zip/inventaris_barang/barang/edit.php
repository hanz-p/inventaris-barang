<?php 
session_start();
include '../config/koneksi.php';
$id = $_GET['id'];
$data = $conn->query("SELECT * FROM barang WHERE id_barang=$id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2>Edit Barang</h2>
    <form method="post">
        <div class="mb-3">
            <label>Nama Barang</label>
            <input type="text" name="nama_barang" value="<?= $data['nama_barang'] ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Kategori</label>
            <select name="id_kategori" class="form-control" required>
                <?php
                $kategori = $conn->query("SELECT * FROM kategori");
                while ($k = $kategori->fetch_assoc()) {
                    $selected = $k['id_kategori'] == $data['id_kategori'] ? 'selected' : '';
                    echo "<option value='{$k['id_kategori']}' $selected>{$k['nama_kategori']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Jumlah Stok</label>
            <input type="number" name="jumlah_stok" value="<?= $data['jumlah_stok'] ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Harga</label>
            <input type="number" name="harga_barang" value="<?= $data['harga_barang'] ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Tanggal Masuk</label>
            <input type="date" name="tanggal_masuk" value="<?= $data['tanggal_masuk'] ?>" class="form-control" required>
        </div>
        <button class="btn btn-primary" type="submit">Update</button>
    </form>
</div>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama_barang'];
    $kategori = $_POST['id_kategori'];
    $stok = (int)$_POST['jumlah_stok'];
    $harga = (int)$_POST['harga_barang'];
    $tanggal = $_POST['tanggal_masuk'];

    // Validasi stok dan harga harus >= 1
    if ($stok < 1 || $harga < 1) {
        echo "<div class='alert alert-danger text-center'>Stok dan harga tidak boleh kurang dari 1!</div>";
    } else {
        $conn->query("UPDATE barang SET nama_barang='$nama', id_kategori='$kategori', jumlah_stok='$stok', harga_barang='$harga', tanggal_masuk='$tanggal' 
                      WHERE id_barang=$id");
        $_SESSION['success'] = "Data berhasil di edit!";
        header("Location: index.php");
        exit;
    }
}

?>
</body>
</html>
