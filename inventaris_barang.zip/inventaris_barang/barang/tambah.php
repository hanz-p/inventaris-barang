<?php 
session_start();
include '../config/koneksi.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Barang</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2>Tambah Barang</h2>
    <form method="post">
        <div class="mb-3">
            <label>Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Kategori</label>
            <select name="id_kategori" class="form-control" required>
                <option value="">Pilih Kategori</option>
                <?php
                $kategori = $conn->query("SELECT * FROM kategori");
                while ($k = $kategori->fetch_assoc()) {
                    echo "<option value='{$k['id_kategori']}'>{$k['nama_kategori']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Jumlah Stok</label>
            <input type="number" name="jumlah_stok" class="form-control" min="1" required>
        </div>
        <div class="mb-3">
            <label>Harga</label>
            <input type="number" name="harga_barang" class="form-control" min="1" required>
        </div>
        <div class="mb-3">
            <label>Tanggal Masuk</label>
            <input type="date" name="tanggal_masuk" class="form-control" required>
        </div>
        <button class="btn btn-primary" type="submit">Simpan</button>
    </form>
</div>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama_barang'];
    $kategori = $_POST['id_kategori'];
    $stok = $_POST['jumlah_stok'];
    $harga = $_POST['harga_barang'];
    $tanggal = $_POST['tanggal_masuk'];

    // Validasi harga dan stok tidak boleh kurang dari 1
    if ($stok < 1 || $harga < 1) {
        echo '<div class="alert alert-danger mt-3">Harga dan stok barang tidak boleh kurang dari 1.</div>';
    } else {
        $conn->query("INSERT INTO barang(nama_barang, id_kategori, jumlah_stok, harga_barang, tanggal_masuk) 
                      VALUES ('$nama', '$kategori', '$stok', '$harga', '$tanggal')");

        $_SESSION['success'] = "Data berhasil ditambahkan!";
        header("Location: index.php");
        exit;
    }
}
?>
</body>
</html>
