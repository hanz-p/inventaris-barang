<?php
session_start();
include '../config/koneksi.php';
?>
<!DOCTYPE html>
<html>

<head>
    <title>Manajemen Barang</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="bg-dark text-white p-3" style="min-height: 100vh; width: 220px;">
            <h4>Inventaris</h4>
            <hr class="text-white">
            <ul class="nav flex-column">
                <li class="nav-item mb-2">
                    <a class="nav-link text-white" href="../barang/index.php">📦 Barang</a>
                </li>
                <li class="nav-item mb-2">
                    <a class="nav-link text-white" href="../kategori/index.php">📁 Kategori</a>
                </li>
            </ul>
        </div>

        <!-- Konten Utama -->
        <div class="p-4 w-100">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success"><?php echo $_SESSION['success'];
                                                    unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <h2>Daftar Barang</h2>
            <a href="../index.php" class="btn btn-outline-secondary mb-3">← Kembali ke Dashboard</a><br>
            <a href="tambah.php" class="btn btn-success mb-2">Tambah Barang</a>
            <form method="get" class="row mb-3 g-2 align-items-center">
                <div class="col-md-4">
                    <input type="text" name="cari" class="form-control" placeholder="Cari nama barang..." value="<?= isset($_GET['cari']) ? $_GET['cari'] : '' ?>">
                </div>
                <div class="col-md-4">
                    <select name="kategori" class="form-control">
                        <option value="">-- Semua Kategori --</option>
                        <?php
                        $kat = $conn->query("SELECT * FROM kategori");
                        while ($k = $kat->fetch_assoc()) {
                            $selected = (isset($_GET['kategori']) && $_GET['kategori'] == $k['id_kategori']) ? 'selected' : '';
                            echo "<option value='{$k['id_kategori']}' $selected>{$k['nama_kategori']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary w-100" type="submit">🔍 Cari</button>
                </div>
                <div class="col-md-2">
                    <a href="index.php" class="btn btn-secondary w-100">Reset</a>
                </div>
            </form>
            

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th>Stok</th>
                        <th>Harga</th>
                        <th>Tanggal Masuk</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $where = "WHERE 1=1";
                    if (!empty($_GET['cari'])) {
                        $cari = $_GET['cari'];
                        $where .= " AND nama_barang LIKE '%$cari%'";
                    }
                    if (!empty($_GET['kategori'])) {
                        $idkat = $_GET['kategori'];
                        $where .= " AND barang.id_kategori = $idkat";
                    }

                    // Pagination
                    $limit = 3; // jumlah data per halaman
                    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                    $start = ($page - 1) * $limit;

                    // Hitung total data
                    $countQuery = "SELECT COUNT(*) AS total FROM barang 
                    JOIN kategori ON barang.id_kategori = kategori.id_kategori $where";
                    $totalData = $conn->query($countQuery)->fetch_assoc()['total'];
                    $totalPages = ceil($totalData / $limit);

                    // Query dengan LIMIT
                    $query = "SELECT barang.*, kategori.nama_kategori FROM barang
                    JOIN kategori ON barang.id_kategori = kategori.id_kategori
                    $where ORDER BY id_barang ASC LIMIT $start, $limit";
                    $barang = $conn->query($query);

                    $no = 1;
                    while ($row = $barang->fetch_assoc()) {
                        echo "<tr>
                        <td>" . ($start + $no++) . "</td>
                        <td>{$row['nama_barang']}</td>
                        <td>{$row['nama_kategori']}</td>
                        <td>{$row['jumlah_stok']}</td>
                        <td>Rp. {$row['harga_barang']}</td>
                        <td>{$row['tanggal_masuk']}</td>
                        <td>
                            <a href='edit.php?id={$row['id_barang']}' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='hapus.php?id={$row['id_barang']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Yakin?\")'>Hapus</a>
                        </td>
                    </tr>";
                    }
                    ?>
                    
                </tbody>
            </table>
            <!-- Navigasi Pagination -->
            <?php
            // Simpan parameter GET selain 'page'
            $params = $_GET;
            unset($params['page']);
            $queryString = http_build_query($params);
            ?>
            <nav>
                <ul class="pagination">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>&<?php echo $queryString; ?>">« Prev</a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&<?php echo $queryString; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>&<?php echo $queryString; ?>">Next »</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <div class="mb-3">
                    <a href="../expor/export_pdf.php" class="btn btn-danger" target="_blank">Export PDF</a>
                </div>


        </div> <!-- Akhir Konten Utama -->
    </div> <!-- Akhir Wrapper -->
</body>

</html>