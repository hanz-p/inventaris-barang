<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Inventaris</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="bg-dark text-white p-3" style="min-height: 100vh; width: 220px;">
            <h4>Inventaris</h4>
            <hr class="text-white">
            <ul class="nav flex-column">
                <li class="nav-item mb-2">
                    <a class="nav-link text-white" href="barang/index.php">📦 Barang</a>
                </li>
                <li class="nav-item mb-2">
                    <a class="nav-link text-white" href="kategori/index.php">📁 Kategori</a>
                </li>
            </ul>
        </div>

        <!-- Konten Utama -->
        <div class="p-5 w-100">
            <h1>Selamat Datang di Sistem Inventaris Barang</h1>
            <p class="lead">Silakan pilih menu di sebelah kiri untuk mengelola barang atau kategori.</p>
        </div>
    </div>
</body>
</html>
