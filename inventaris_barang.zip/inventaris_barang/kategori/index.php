<?php
session_start();
include '../config/koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Kategori</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="d-flex">
    <!-- Sidebar -->
    <div class="bg-dark text-white p-3" style="min-height: 100vh; width: 220px;">
        <h4>Inventaris</h4>
        <hr class="text-white">
        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a class="nav-link text-white" href="../barang/index.php">📦 Barang</a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link text-white" href="../kategori/index.php">📁 Kategori</a>
            </li>
        </ul>
    </div>

    <!-- Konten Utama -->
    <div class="container mt-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <h2>Kategori Barang</h2>
        <a href="../index.php" class="btn btn-outline-secondary">← Kembali ke Dashboard</a><br><br>
        <div class="mb-3 d-flex gap-2">
            <a href="tambah.php" class="btn btn-success">Tambah Kategori</a>
        </div>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Kategori</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $kategori = $conn->query("SELECT * FROM kategori");
            $no = 1;
            $start = 0;
            while ($row = $kategori->fetch_assoc()):
            ?>
                <tr>
                    <td><?= $start + $no++; ?></td>
                    <td><?= $row['nama_kategori']; ?></td>
                    <td>
                        <a href="edit.php?id=<?= $row['id_kategori']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="hapus.php?id=<?= $row['id_kategori']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin?')">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
