<?php 
session_start();
include '../config/koneksi.php';
$id = $_GET['id'];
$data = $conn->query("SELECT * FROM kategori WHERE id_kategori=$id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Kategori</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2>Edit Kategori</h2>
    <form method="post">
        <div class="mb-3">
            <label>Nama Kategori</label>
            <input type="text" name="nama_kategori" value="<?= $data['nama_kategori'] ?>" class="form-control" required>
        </div>
        <button class="btn btn-primary" type="submit">Update</button>
    </form>
</div>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama_kategori'];
    $conn->query("UPDATE kategori SET nama_kategori='$nama' WHERE id_kategori=$id");
    $_SESSION['success'] = "Data berhasil di edit!";
     header("Location: index.php");
     exit;
}
?>
</body>
</html>
