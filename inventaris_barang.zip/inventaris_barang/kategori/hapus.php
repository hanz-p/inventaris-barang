<?php
session_start();
include '../config/koneksi.php';
$id = $_GET['id'];
$conn->query("DELETE FROM kategori WHERE id_kategori=$id");
$_SESSION['success'] = "Data berhasil di hapus!";
    header("Location: index.php");
    exit;
?>
