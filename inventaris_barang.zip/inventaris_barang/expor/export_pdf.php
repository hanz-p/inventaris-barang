<?php
require '../config/koneksi.php';
require '../vendor/autoload.php'; // jika pakai Composer

use Dompdf\Dompdf;
use Dompdf\Options;

$options = new Options();
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);

// Ambil data dari database
$data = $conn->query("SELECT barang.*, kategori.nama_kategori FROM barang 
    JOIN kategori ON barang.id_kategori = kategori.id_kategori");

if ($data === false) {
    die('Error: Query gagal dijalankan.');
}

// Bangun HTML untuk isi PDF
$html = '
    <style>
        body { font-family: Arial, sans-serif; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
        h3 { text-align: center; }
    </style>
    <h3>Laporan Data Barang</h3>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Kategori</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Tanggal Masuk</th>
            </tr>
        </thead>
        <tbody>';

$no = 1; // Nomor urut mulai dari 1
while ($row = $data->fetch_assoc()) {
    $tanggal_masuk = date('d-m-Y', strtotime($row['tanggal_masuk']));  // Format tanggal

    $html .= '
        <tr>
            <td>' . $no++ . '</td> <!-- Menambahkan nomor urut -->
            <td>' . htmlspecialchars($row['nama_barang']) . '</td>
            <td>' . htmlspecialchars($row['nama_kategori']) . '</td>
            <td>' . $row['jumlah_stok'] . '</td>
            <td>Rp. ' . number_format($row['harga_barang'], 0, ',', '.') . '</td>
            <td>' . $tanggal_masuk . '</td>
        </tr>';
}

$html .= '</tbody></table>';

// Load dan render PDF
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Output file ke browser
$dompdf->stream("data_barang.pdf", ["Attachment" => false]);
?>
